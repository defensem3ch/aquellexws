sndtest: record until the track loops itself once.
happyhippo: record until 1:15 (that's when the loop point occurs)

cheers!

~aqx

https://aquellex.ws/goodies/tutorial/game-boy-comparison/